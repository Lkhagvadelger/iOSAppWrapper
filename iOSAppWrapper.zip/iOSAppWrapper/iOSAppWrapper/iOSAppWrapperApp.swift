//
//  iOSAppWrapperApp.swift
//  iOSAppWrapper
//
//  Created by Turbat Davaakhishigt on 2023.01.02.
//

import SwiftUI

@main
struct iOSAppWrapperApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
