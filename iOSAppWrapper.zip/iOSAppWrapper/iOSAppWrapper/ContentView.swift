//
//  ContentView.swift
//  iOSAppWrapper
//
//  Created by Turbat Davaakhishigt on 2023.01.02.
//

import Foundation
import SwiftUI
import WebKit

struct ContentView: View {
    var body: some View {
        LocalWebview()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
struct LocalWebview: UIViewRepresentable {
        
    func makeUIView(context: Context) -> WKWebView {
        
 
        let htmlUrl = Bundle.main.url(forResource: "index", withExtension: "html")
       
let wkWebview = WKWebView()
        wkWebview.loadFileURL(htmlUrl!, allowingReadAccessTo: htmlUrl!)
        return wkWebview
        
    }
    
    func updateUIView(_ uiView: WKWebView, context: UIViewRepresentableContext<LocalWebview>) {
        
    }
    
}
